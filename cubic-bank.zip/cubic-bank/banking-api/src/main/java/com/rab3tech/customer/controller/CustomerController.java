package com.rab3tech.customer.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rab3tech.customer.service.LoginService;
import com.rab3tech.customer.service.PayeeInfoService;
import com.rab3tech.vo.ApplicationResponseVO;
import com.rab3tech.vo.LoginRequestVO;
import com.rab3tech.vo.LoginVO;
import com.rab3tech.vo.PayeeInfoVO;

@RestController // It will take the JSON Data and give the JSON data back
@CrossOrigin(origins = "*") // It means the request can come from anywhere
//@RequestMapping("/v3")
public class CustomerController {

	@Autowired
	private LoginService loginService;

	@Autowired
	private PayeeInfoService payeeInfoService;

	@PostMapping("/user/login")
	public ApplicationResponseVO authUser(@RequestBody LoginRequestVO loginRequestVO) {
		Optional<LoginVO> optional = loginService.findUserByUsername(loginRequestVO.getUsername());
		ApplicationResponseVO applicationResponseVO = new ApplicationResponseVO();
		if (optional.isPresent()) {
			applicationResponseVO.setCode(200);
			applicationResponseVO.setStatus("success");
			applicationResponseVO.setMessage("Userid is correct");
		} else {
			applicationResponseVO.setCode(400);
			applicationResponseVO.setStatus("fail");
			applicationResponseVO.setMessage("Userid is not correct");
		}
		return applicationResponseVO;
	}

	@GetMapping("/customer/deletePayee/{payeeId}")
	public ApplicationResponseVO deletePayee(@PathVariable int payeeId) {
		ApplicationResponseVO applicationResponseVO = new ApplicationResponseVO();
		try {
		payeeInfoService.deletePayeeCustomerAccount(payeeId);
		applicationResponseVO.setCode(200);
		applicationResponseVO.setStatus("success");
		applicationResponseVO.setMessage("Payee has been deleted");
		}
		
		catch(Exception e) {
			applicationResponseVO.setCode(404);
			applicationResponseVO.setStatus("error");
			applicationResponseVO.setMessage("Payee cannot be deleted");
			e.printStackTrace();
		 }

		return applicationResponseVO;

	}
	
	
	
	
}
