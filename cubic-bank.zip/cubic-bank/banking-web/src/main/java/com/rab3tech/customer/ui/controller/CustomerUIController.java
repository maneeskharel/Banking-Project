package com.rab3tech.customer.ui.controller;

import java.io.IOException;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rab3tech.customer.service.CustomerService;
import com.rab3tech.customer.service.LoginService;
import com.rab3tech.customer.service.PayeeInfoService;
import com.rab3tech.customer.service.TransactionService;
import com.rab3tech.customer.service.impl.CustomerAccountInfoService;
import com.rab3tech.customer.service.impl.CustomerEnquiryService;
import com.rab3tech.customer.service.impl.SecurityQuestionService;
import com.rab3tech.email.service.EmailService;
import com.rab3tech.vo.ChangePasswordVO;
import com.rab3tech.vo.CustomerSavingVO;
import com.rab3tech.vo.CustomerSecurityQueAnsVO;
import com.rab3tech.vo.CustomerUpdateVO;
import com.rab3tech.vo.CustomerVO;
import com.rab3tech.vo.EmailVO;
import com.rab3tech.vo.LoginVO;
import com.rab3tech.vo.PayeeInfoVO;
import com.rab3tech.vo.SecurityQuestionsVO;
import com.rab3tech.vo.TransactionVO;

/**
 * 
 * @author nagendra This class for customer GUI
 *
 */
@Controller
public class CustomerUIController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerUIController.class);

	@Autowired
	private CustomerEnquiryService customerEnquiryService;

	@Autowired
	private CustomerService customerService;

	@Autowired
	private SecurityQuestionService securityQuestionService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private LoginService loginService;

	@Autowired
	private PayeeInfoService payeInfoService;

	@Autowired
	private CustomerAccountInfoService customerAccountService;

	@Autowired
	private TransactionService transactionService;

	@GetMapping("/customer/update/profile")
	public String showCustomerProfile(String username, Model model, HttpSession session) {
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO2 != null) {
			CustomerVO customerVO = customerService.findByEmail(loginVO2.getUsername());

			model.addAttribute("customerVO", customerVO);

			List<SecurityQuestionsVO> questionsVOs = securityQuestionService.findAll();
			model.addAttribute("questionsVOs", questionsVOs);
		} else {
			model.addAttribute("error", "Please enter the username again!!!!!");
			return "customer/login";
		}
		return "customer/showProfile";

	}

	@GetMapping("/customer/Payee/Beneficiary")
	public String customerPayeeBeneficiary(String username, Model model, HttpSession session) {
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO2 != null) {
			CustomerVO customerVO = customerService.findByEmail(loginVO2.getUsername());

			model.addAttribute("customerVO", customerVO);

			List<SecurityQuestionsVO> questionsVOs = securityQuestionService.findAll();
			model.addAttribute("questionsVOs", questionsVOs);
		} else {
			model.addAttribute("error", "Please enter the username again!!!!!");
			return "customer/login";
		}
		return "customer/showProfile";

	}

	@PostMapping("/customer/update/profile")
	public String customerUpdateProfile(@ModelAttribute CustomerVO customerVO, Model model, HttpSession session) {
		logger.debug("customerUpdateProfile");
		logger.debug(customerVO.toString());
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO2 != null) {
			customerService.update(customerVO);
			List<SecurityQuestionsVO> questionsVOs = securityQuestionService.findAll();
			model.addAttribute("questionsVOs", questionsVOs);
			model.addAttribute("message", "You're Profile is update succesfully");
		} else {
			model.addAttribute("error", "Please enter the username again!!!!!");
			return "customer/login";
		}
		logger.debug(customerVO.toString());
		return "customer/showProfile";
	}

	@PostMapping("/customer/changePassword")
	public String saveCustomerQuestions(@ModelAttribute ChangePasswordVO changePasswordVO, Model model,
			HttpSession session) {
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		String userid = loginVO2.getUsername();
		changePasswordVO.setLoginid(userid);
		String viewName = "customer/dashboard";
		Boolean status = loginService.checkPasswordValid(userid, changePasswordVO.getCurrentPassword());
		if (status) {
			if (changePasswordVO.getNewPassword().equals(changePasswordVO.getConfirmPassword())) {
				loginService.changePassword(changePasswordVO);
				viewName = "customer/dashboard";
			} else {
				model.addAttribute("error", "your new password is n't correct");
				return "customer/login"; // login.html
			}
		} else {
			model.addAttribute("error", "your username and password is not correct");
			return "customer/login"; // login.html
		}

		return viewName;
	}

	@PostMapping("/customer/securityQuestion")
	public String saveCustomerQuestions(
			@ModelAttribute("customerSecurityQueAnsVO ") CustomerSecurityQueAnsVO customerSecurityQueAnsVO, Model model,
			HttpSession session) {
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		String userid = loginVO2.getUsername();
		customerSecurityQueAnsVO.setLoginid(userid);
		securityQuestionService.save(customerSecurityQueAnsVO);
		return "customer/changePassword";
	}

	// http://localhost:444/customer/account/registration?cuid=1585a34b5277-dab2-475a-b7b4-042e032e8121603186515
	@GetMapping("/customer/account/registration")
	public String showCustomerRegistrationPage(@RequestParam String cuid, Model model) {

		logger.debug("cuid = " + cuid);
		Optional<CustomerSavingVO> optional = customerEnquiryService.findCustomerEnquiryByUuid(cuid);
		CustomerVO customerVO = new CustomerVO();

		if (!optional.isPresent()) {
			return "customer/error";
		} else {
			// model is used to carry data from controller to the view =- JSP/
			CustomerSavingVO customerSavingVO = optional.get();
			customerVO.setEmail(customerSavingVO.getEmail());
			customerVO.setName(customerSavingVO.getName());
			customerVO.setMobile(customerSavingVO.getMobile());
			customerVO.setAddress(customerSavingVO.getLocation());
			customerVO.setToken(cuid);
			logger.debug(customerSavingVO.toString());
			// model - is hash map which is used to carry data from controller to thyme
			// leaf!!!!!
			// model is similar to request scope in jsp and servlet
			model.addAttribute("customerVO", customerVO);
			return "customer/customerRegistration"; // thyme leaf
		}
	}

	@PostMapping("/customer/account/registration")
	public String createCustomer(@ModelAttribute CustomerVO customerVO, Model model) {
		// saving customer into database
		logger.debug(customerVO.toString());
		customerVO = customerService.createAccount(customerVO);
		// Write code to send email

		EmailVO mail = new EmailVO(customerVO.getEmail(), "javahunk2020@gmail.com",
				"Regarding Customer " + customerVO.getName() + "  userid and password", "", customerVO.getName());
		mail.setUsername(customerVO.getUserid());
		mail.setPassword(customerVO.getPassword());
		emailService.sendUsernamePasswordEmail(mail);
		System.out.println(customerVO);
		model.addAttribute("loginVO", new LoginVO());
		model.addAttribute("message", "Your account has been setup successfully , please check your email.");
		return "customer/login";
	}

	@GetMapping(value = { "/customer/account/enquiry", "/", "/mocha", "/welcome" })
	public String showCustomerEnquiryPage(Model model) {
		CustomerSavingVO customerSavingVO = new CustomerSavingVO();
		// model is map which is used to carry object from controller to view
		model.addAttribute("customerSavingVO", customerSavingVO);
		return "customer/customerEnquiry"; // customerEnquiry.html
	}

	@PostMapping("/customer/account/enquiry")
	public String submitEnquiryData(@ModelAttribute CustomerSavingVO customerSavingVO, Model model) {
		boolean status = customerEnquiryService.emailNotExist(customerSavingVO.getEmail());
		logger.info("Executing submitEnquiryData");
		if (status) {
			CustomerSavingVO response = customerEnquiryService.save(customerSavingVO);
			logger.debug("Hey Customer , your enquiry form has been submitted successfully!!! and appref "
					+ response.getAppref());
			model.addAttribute("message",
					"Hey Customer , your enquiry form has been submitted successfully!!! and appref "
							+ response.getAppref());
		} else {
			model.addAttribute("message", "Sorry , this email is already in use " + customerSavingVO.getEmail());
		}
		return "customer/success"; // customerEnquiry.html

	}

	@GetMapping("/customer/forgetPassword")
	public String getUserName(String username, Model model, HttpSession session) {
		Optional<LoginVO> optional = loginService.findUserByUsername(username);
		if (optional.isPresent()) {
			LoginVO loginVO2 = optional.get();
			loginVO2.setPassword("");
			session.setAttribute("userSessionVO", loginVO2);
		}
		CustomerSecurityQueAnsVO customerSecurityQueAnsVO = securityQuestionService.getUsername(username);
		model.addAttribute("customerSecurityQueAnsVO", customerSecurityQueAnsVO);

		return "customer/verifyQuestionPassword";

	}

	@GetMapping("/customer/checkAnswer")
	public String resetPassword(@ModelAttribute CustomerSecurityQueAnsVO customerSecurityQueAnsVO, Model model) {
		String ans1 = securityQuestionService.findAnsById(customerSecurityQueAnsVO.getQuestionid().get(0));
		String ans2 = securityQuestionService.findAnsById(customerSecurityQueAnsVO.getQuestionid().get(1));
		if (ans1.equalsIgnoreCase(customerSecurityQueAnsVO.getSecurityQuestion1())
				&& (ans2.equalsIgnoreCase(customerSecurityQueAnsVO.getSecurityQuestion2()))) {

			return "customer/resetPassword";
		}

		model.addAttribute("message", "you give the wrong answer");
		return "customer/login";
	}

	@PostMapping("/customer/change/Password")
	public String savePassword(@ModelAttribute ChangePasswordVO changePasswordVO, Model model, HttpSession session) {
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		String userid = loginVO2.getUsername();
		changePasswordVO.setLoginid(userid);
		if (changePasswordVO.getNewPassword().equals(changePasswordVO.getConfirmPassword())) {
			loginService.changePassword(changePasswordVO);
			return "customer/dashboard";
		} else {

			model.addAttribute("error", "your username and password is not correct");
		}
		return "customer/login"; // login.html

	}

	@GetMapping("/customer/addPayee")
	public String goToPayeePage() {
		return "customer/addPayee";
	}

	@PostMapping("/customer/account/savePayee")
	public String savecustomerPayee(HttpSession session, @ModelAttribute PayeeInfoVO payeeInfoVO, Model model) {
		LoginVO loginVO = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO != null) {
			payeeInfoVO.setCustomerId(loginVO.getUsername());
			String message = payeInfoService.savePayeInfo(payeeInfoVO);
			model.addAttribute("message", message);
		} else {
			model.addAttribute("error", "please login to proceed further");
			return ("customer/login");
		}
		return "customer/addPayee";
	}

	@GetMapping(value = { "/customer/PayeeList" })
	public String payeeList(@ModelAttribute PayeeInfoVO payeeInfoVO, Model model, HttpSession session) {
		logger.info("showPayeeBeneficiary is called!!!");
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		String userid = loginVO2.getUsername();
		List<PayeeInfoVO> infoVOs = payeInfoService.findByCustomerId(userid);
		model.addAttribute("applicants", infoVOs);
		return "customer/PayeeList"; // login.html
	}

	@GetMapping("/customer/payee/Remove")
	public String payeeRemove(Model model, int payeeid) throws Exception {
		payeInfoService.deletePayeeCustomerAccount(payeeid);
		return "redirect:/customer/PayeeList";
	}

	@PostMapping("/customer/updateAccountCustomer")
	public String updateAccountCustomer(@ModelAttribute PayeeInfoVO payeeInfoVO, Model model, HttpSession session)
			throws IOException {
		logger.debug("savePayee" + payeeInfoVO);
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO2 != null) {
			payeeInfoVO.setCustomerId(loginVO2.getUsername());
			try {
				payeInfoService.updateProfile(payeeInfoVO);
			} catch (Exception e) {
				e.printStackTrace();
			}
			model.addAttribute("message", "Payee Details has been Updated");
		} else {
			model.addAttribute("error", "Please login to proceed further");
			return "customer/login";
		}

		// redirect to show all the records of the current customer in the database!
		return "redirect:/customer/PayeeList";
	}

	@GetMapping(value = { "/customer/loadfundTransfer" })
	public String fundTransfer(@ModelAttribute PayeeInfoVO payeeInfoVO, Model model, HttpSession session) {
		logger.info("showPayeeBeneficiary is called!!!");
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO2 != null) {
			String userid = loginVO2.getUsername();
			List<PayeeInfoVO> infoVOs = payeInfoService.findByCustomerId(userid);
			model.addAttribute("applicants", infoVOs);
			return "customer/fundTransfer";
		} else {
			model.addAttribute("error", "Please login to proceed further");
			return "customer/login";
		}

	}

	@PostMapping("/customer/transferFund")
	public String transferFund(@ModelAttribute TransactionVO transactionVO, Model model, HttpSession session) {
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO2 != null) {
			String userid = loginVO2.getUsername();
			transactionVO.setCustomerId(userid);
			String message = transactionService.transferFund(transactionVO);
			model.addAttribute("message", message);
			return "customer/fundTransfer";
		}

		else {
			model.addAttribute("error", "Please login to proceed further");
			return "customer/login";

		}
	}

	
	@GetMapping(value = {"/customer/accountStatement"})
	public String accountStatement(  Model model, HttpSession session) {
		LoginVO loginVO2 = (LoginVO) session.getAttribute("userSessionVO");
		if (loginVO2 != null) {
			String userid = loginVO2.getUsername();
		List<TransactionVO>	transactionVOs =transactionService.getAllTransaction(userid);
		model.addAttribute("transactionVOs", transactionVOs);
			return "customer/accountStatement";
		} else {
			model.addAttribute("error", "Please login to proceed further");
			return "customer/login";
		}

	}
	
	
	@GetMapping(value = { "/customer/checkBookRequest" })
	public String checkBookRequest(Model model) {
		CustomerSavingVO customerSavingVO = new CustomerSavingVO();
		// model is map which is used to carry object from controller to view
		model.addAttribute("customerSavingVO", customerSavingVO);
	      return "customer/checkBook";
	}

	
	
	
	
	@PostMapping("/customer/checkBookEnquiry")
	public String checkBookEnquiry(@ModelAttribute CustomerSavingVO customerSavingVO, Model model) {
		boolean status = customerEnquiryService.emailNotExist(customerSavingVO.getEmail());
		logger.info("Executing submitEnquiryData");
		if (status) {
			CustomerSavingVO response = customerEnquiryService.save(customerSavingVO);
			logger.debug("Hey Customer , your enquiry form has been submitted successfully!!! and appref "
					+ response.getAppref());
			model.addAttribute("message",
					"Hey Customer , your enquiry form has been submitted successfully!!! and appref "
							+ response.getAppref());
		} else {
			model.addAttribute("message", "Sorry , this email is already in use " + customerSavingVO.getEmail());
		}
		return "customer/success"; // customerEnquiry.html

	}
	
	

}
