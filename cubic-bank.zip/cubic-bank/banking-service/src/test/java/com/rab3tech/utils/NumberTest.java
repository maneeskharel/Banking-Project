package com.rab3tech.utils;

import static org.junit.Assert.*;

import org.junit.Test;

public class NumberTest {

	@Test
	public void testFactorial() {
		Number n = new Number(3);
		 int result = n.factorial();
		assertEquals(6, result);
		
	}

}
