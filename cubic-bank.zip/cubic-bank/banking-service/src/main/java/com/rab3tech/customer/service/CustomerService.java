package com.rab3tech.customer.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rab3tech.vo.CustomerAccountInfoVO;
import com.rab3tech.vo.CustomerUpdateVO;
import com.rab3tech.vo.CustomerVO;


public interface CustomerService {

	CustomerVO createAccount(CustomerVO customerVO);

	CustomerAccountInfoVO createBankAccount(int csaid);
     CustomerVO findByEmail(String username);
    void update(CustomerVO customerVO);

	List<CustomerVO> findCustomers();

	byte[] findPhotoByid(int cid);
	
	void updateProfile(CustomerUpdateVO customerVO);
	

}
