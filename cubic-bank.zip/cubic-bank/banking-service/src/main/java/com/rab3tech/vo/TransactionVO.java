package com.rab3tech.vo;

import java.util.Date;

public class TransactionVO {
	
	private int payeeId;
	private String description;
	private float amount ;
	private String customerId;
	private Date transactionDate;
	private String transactionType;
	private String debitAccountNumber;
	private PayeeInfoVO payee;
	 
	
	public PayeeInfoVO getPayee() {
		return payee;
	}
	public void setPayee(PayeeInfoVO payee) {
		this.payee = payee;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getDebitAccountNumber() {
		return debitAccountNumber;
	}
	public void setDebitAccountNumber(String debitAccountNumber) {
		this.debitAccountNumber = debitAccountNumber;
	}
	public int getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	@Override
	public String toString() {
		return "TransactionVO [payeeId=" + payeeId + ", description=" + description + ", amount=" + amount
				+ ", customerId=" + customerId + ", transactionDate=" + transactionDate + ", transactionType="
				+ transactionType + ", debitAccountNumber=" + debitAccountNumber + "]";
	}
	

}
 