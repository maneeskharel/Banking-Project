package com.rab3tech.customer.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.rab3tech.vo.ChangePasswordVO;
import com.rab3tech.vo.LoginVO;

@Service
public interface LoginService {

	Optional<LoginVO> authUser(LoginVO loginVO);

	Optional<LoginVO> findUserByUsername(String loginid);

	void changePassword(ChangePasswordVO changePasswordVO);

	boolean checkPasswordValid(String username, String password);

	String updatePasscode(String emailOrUsername, String passcode);


}
