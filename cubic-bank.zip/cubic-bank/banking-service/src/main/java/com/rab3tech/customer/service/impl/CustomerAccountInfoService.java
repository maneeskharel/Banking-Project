package com.rab3tech.customer.service.impl;

public interface CustomerAccountInfoService {

}
