package com.rab3tech.customer.service.impl;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rab3tech.admin.dao.repository.AccountStatusRepository;
import com.rab3tech.admin.dao.repository.MagicCustomerRepository;
import com.rab3tech.customer.dao.repository.CustomerAccountApprovedRepository;
import com.rab3tech.customer.dao.repository.CustomerAccountEnquiryRepository;
import com.rab3tech.customer.dao.repository.CustomerAccountInfoRepository;
import com.rab3tech.customer.dao.repository.CustomerQuestionsAnsRepository;
import com.rab3tech.customer.dao.repository.CustomerRepository;
import com.rab3tech.customer.dao.repository.RoleRepository;
import com.rab3tech.customer.service.CustomerService;
import com.rab3tech.dao.entity.AccountStatus;
import com.rab3tech.dao.entity.Customer;
import com.rab3tech.dao.entity.CustomerAccountInfo;
import com.rab3tech.dao.entity.CustomerQuestionAnswer;
import com.rab3tech.dao.entity.CustomerSaving;
import com.rab3tech.dao.entity.CustomerSavingApproved;
import com.rab3tech.dao.entity.Login;
import com.rab3tech.dao.entity.Role;
import com.rab3tech.mapper.CustomerMapper;
import com.rab3tech.utils.AccountStatusEnum;
import com.rab3tech.utils.PasswordGenerator;
import com.rab3tech.utils.Utils;
import com.rab3tech.vo.CustomerAccountInfoVO;
import com.rab3tech.vo.CustomerSecurityQueAnsVO;
import com.rab3tech.vo.CustomerUpdateVO;
import com.rab3tech.vo.CustomerVO;


@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	//import org.slf4j.Logger;
	//import org.slf4j.LoggerFactory;
	private static final Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);

	@Autowired
	private MagicCustomerRepository customerRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private CustomerAccountEnquiryRepository customerAccountEnquiryRepository;

	@Autowired
	private AccountStatusRepository accountStatusRepository;

	@Autowired
	private CustomerAccountInfoRepository customerAccountInfoRepository;



	@Autowired
	private CustomerRepository customerRepositorys;

	@Autowired
	private CustomerAccountApprovedRepository customerAccountApprovedRepository;
	

	@Autowired
	private CustomerQuestionsAnsRepository customerQuestionsAnsRepository;
	
	@Autowired
	private SecurityQuestionService securityQuestionService;
	

	

	@Override
	public CustomerVO createAccount(CustomerVO customerVO) {
		Customer pcustomer = new Customer();
		BeanUtils.copyProperties(customerVO, pcustomer);
		Login login = new Login();
		login.setNoOfAttempt(3);
		login.setLoginid(customerVO.getEmail());
		login.setName(customerVO.getName());
		String genPassword = PasswordGenerator.generateRandomPassword(8);
		customerVO.setPassword(genPassword);
		login.setPassword(bCryptPasswordEncoder.encode(genPassword));
		login.setToken(customerVO.getToken());
		login.setLocked("no");

		Role entity = roleRepository.findById(3).get();
		Set<Role> roles = new HashSet<>();
		roles.add(entity);
		// setting roles inside login
		login.setRoles(roles);
		// setting login inside
		pcustomer.setLogin(login);
		Customer dcustomer = customerRepository.save(pcustomer);
		customerVO.setId(dcustomer.getId());
		customerVO.setUserid(customerVO.getUserid());

		// change the status
		Optional<CustomerSaving> optional = customerAccountEnquiryRepository.findByEmail(dcustomer.getEmail());
		if (optional.isPresent()) {
			CustomerSaving customerSaving = optional.get();
			// One to one mapping
			AccountStatus accountStatus = accountStatusRepository.findByCode(AccountStatusEnum.REGISTERED.getCode()).get();
			customerSaving.setStatus(accountStatus);

		}
		return customerVO;
	}

	@Override
	public CustomerAccountInfoVO createBankAccount(int csaid) {
		// logic
		String customerAccount = Utils.generateAccountNumber();
		CustomerSaving customerSaving = customerAccountEnquiryRepository.findById(csaid).get();

		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
		customerAccountInfo.setAccountNumber(customerAccount);
		customerAccountInfo.setAccountType(customerSaving.getAccType());
		customerAccountInfo.setAvBalance(1000.0F);
		customerAccountInfo.setBranch(customerSaving.getLocation());
		customerAccountInfo.setCurrency("$");
		Customer customer = customerRepository.findByEmail(customerSaving.getEmail()).get();
		customerAccountInfo.setCustomerId(customer.getLogin());
		customerAccountInfo.setStatusAsOf(new Date());
		customerAccountInfo.setTavBalance(1000.0F);
		CustomerAccountInfo customerAccountInfo2 = customerAccountInfoRepository.save(customerAccountInfo);

		CustomerSavingApproved customerSavingApproved = new CustomerSavingApproved();
		BeanUtils.copyProperties(customerSaving, customerSavingApproved);
		customerSavingApproved.setAccType(customerSaving.getAccType());
		customerSavingApproved.setStatus(customerSaving.getStatus());
		// saving entity into customer_saving_enquiry_approved_tbl
		customerAccountApprovedRepository.save(customerSavingApproved);

		// delete data from
		customerAccountEnquiryRepository.delete(customerSaving);

		CustomerAccountInfoVO accountInfoVO = new CustomerAccountInfoVO();
		BeanUtils.copyProperties(customerAccountInfo2, accountInfoVO);
		return accountInfoVO;

	}

	@Override
	public CustomerVO findByEmail(String username) {
		
		Customer customer = customerRepositorys.findByEmail(username).get();
		CustomerVO customerVO = new CustomerVO();
		BeanUtils.copyProperties(customer,customerVO);
		
		List<CustomerQuestionAnswer>customerQuestionAnswers = customerQuestionsAnsRepository.findAll();
		customerVO.setQuestion1(customerQuestionAnswers.get(0).getQuestion());
		customerVO.setQuestion2(customerQuestionAnswers.get(1).getQuestion());
		customerVO.setAnswer1(customerQuestionAnswers.get(0).getAnswer());
		customerVO.setAnswer2(customerQuestionAnswers.get(1).getAnswer());
		return customerVO;
		
	}
	
	
	@Override
	public void update(CustomerVO customerVO) {
		String methodName = "update";
		logger.debug(methodName);
	Customer customer = customerRepositorys.findByEmail(customerVO.getEmail()).get(); //check the available customer in database
	 BeanUtils.copyProperties(customerVO, customer, getNullPropertyNames(customerVO));
	customerRepositorys.save(customer);
	List<CustomerQuestionAnswer> questionAnswers = customerQuestionsAnsRepository.findQuestionAnswer(customerVO.getEmail());
	if(!(questionAnswers.get(0).getAnswer().equals(customerVO.getAnswer1()) && questionAnswers.get(1).getAnswer().equals(customerVO.getAnswer2())&&
	((questionAnswers.get(0).getQuestion().equals(customerVO.getQuestion1()) && questionAnswers.get(1).getQuestion().equals(customerVO.getQuestion2()))))){
		CustomerSecurityQueAnsVO ansVO = new CustomerSecurityQueAnsVO();
		ansVO.setLoginid(customerVO.getEmail());
		ansVO.setSecurityQuestion1(customerVO.getQuestion1());
		ansVO.setSecurityQuestion2(customerVO.getQuestion2());
		ansVO.setSecurityQuestionAnswer1(customerVO.getAnswer1());
		ansVO.setSecurityQuestionAnswer2(customerVO.getAnswer2());
		securityQuestionService.save(ansVO);

	}
		
		/*
		 * Customer customer = customerRepositorys.findByEmail(email).get();
		 * customer.setAddress(customerVO.getAddress());
		 * customer.setAge(customerVO.getAge()); customer.setDob(customerVO.getDob());
		 * customer.setName(customerVO.getName()); customer.setDoe(customer.getDoe());
		 * customer.setEmail(customerVO.getEmail());
		 * customer.setFather(customerVO.getFather());
		 * customer.setGender(customer.getGender());
		 * customer.setQualification(customer.getQualification());
		 * customer.setId(customer.getId()); customer.setDom(customer.getDom());
		 * customerRepositorys.save(customer);
		 */
   }
	
	
	 public  String[] getNullPropertyNames(Object source) {
		 BeanWrapper src = new BeanWrapperImpl(source);
		java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();
		Set<String> emptyNames = new HashSet<String>();
		for (java.beans.PropertyDescriptor pd : pds) {
			Object srcValue = src.getPropertyValue(pd.getName());
			if (srcValue == null)
				emptyNames.add(pd.getName());
		}
		String[] result = new String[emptyNames.size()];
		return emptyNames.toArray(result);
	}
	 
	 
	 
	 @Override
		public List<CustomerVO> findCustomers() {
			List<Customer> customers = customerRepository.findAll();
			/*
			 * List<CustomerVO> customerVOs=new ArrayList<CustomerVO>(); 
			 * for(Customer customer:customers) {
			 *  CustomerVO customerVO=CustomerMapper.toVO(customer);
			 * customerVOs.add(customerVO); } return customerVOs;
			 */
			return customers.stream(). //Stream<Customer>
			map(CustomerMapper::toVO).//Stream<CustomerVO>
			collect(Collectors.toList()); //List<CustomerVO>
		}

		@Override
		public byte[] findPhotoByid(int cid) {
			Optional<Customer> optionalCustomer=customerRepository.findById(cid);
			if(optionalCustomer.isPresent()) {
				return optionalCustomer.get().getImage();
			}else {
				return null;
			}

		}

		@Override
		public void updateProfile(CustomerUpdateVO customerVO) {
			//I have loaded entity inside persistence context - >>Session
			Customer customer=customerRepository.findById(customerVO.getCid()).get();
			try {
		    customer.setImage(customerVO.getPhoto().getBytes());
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			customer.setName(customerVO.getName());
			customer.setMobile(customerVO.getMobile());
			customer.setDom(new Timestamp(new Date().getTime()));
			customerRepository.save(customer);
			
		}

}
