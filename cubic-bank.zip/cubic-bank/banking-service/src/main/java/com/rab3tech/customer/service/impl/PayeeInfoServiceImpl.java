package com.rab3tech.customer.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rab3tech.customer.dao.repository.CustomerAccountInfoRepository;
import com.rab3tech.customer.dao.repository.CustomerRepository;
import com.rab3tech.customer.dao.repository.LoginRepository;
import com.rab3tech.customer.dao.repository.PayeeInfoRepository;
import com.rab3tech.customer.service.PayeeInfoService;
import com.rab3tech.dao.entity.Customer;
import com.rab3tech.dao.entity.CustomerAccountInfo;
import com.rab3tech.dao.entity.Login;
import com.rab3tech.dao.entity.PayeeInfo;
import com.rab3tech.vo.PayeeInfoVO;

@Service
@Transactional
public class PayeeInfoServiceImpl implements PayeeInfoService {

	@Autowired
	private PayeeInfoRepository payeeInfoRepository;

	@Autowired
	private CustomerAccountInfoRepository customerAccountInfoRepository;


	
	@Autowired
	private LoginRepository loginRepository;
	

	@Override
	public String savePayeInfo(PayeeInfoVO payeeInfoVO) {
		String message = null;
		//Customer customer = customerRepository.findByEmail(payeeInfoVO.getCustomerId()).get();
		Login login  = loginRepository.findByLoginid(payeeInfoVO.getCustomerId()).get();
		
		
		Optional<CustomerAccountInfo> mySavingAccount = customerAccountInfoRepository.findAccountByLogin(login);
		if (mySavingAccount.isPresent()) {
			CustomerAccountInfo myOwnAccount = mySavingAccount.get();
			if (!myOwnAccount.getAccountType().getCode().equalsIgnoreCase("AC001")) {
				message = "your savings account is not active";
				return message;
			}
		} else {
			message = "You do not have a valid savings account";
			return message;
		}
		Optional<CustomerAccountInfo> accountNum = customerAccountInfoRepository.findByAccountNumber(payeeInfoVO.getPayeeAccountNo());
		if (!accountNum.isPresent()) {
			message = "payee account number is invalid";
			return message;
		}
		if (payeeInfoRepository.findByCustomerIdAndPayeeAccountNo(payeeInfoVO.getCustomerId(), payeeInfoVO.getPayeeAccountNo())
				.isPresent()) {
			message = "Beneficiary with same account number already exits";
			return message;
		}
		if (payeeInfoRepository.findByCustomerIdAndPayeeName(payeeInfoVO.getCustomerId(), payeeInfoVO.getPayeeName())
				.isPresent()) {
			message = "Beneficiary with same name already exits";
			return message;
		}
		if (payeeInfoRepository.findByCustomerIdAndPayeeNickName(payeeInfoVO.getCustomerId(), payeeInfoVO.getPayeeNickName())
				.isPresent()) {
			message = "Beneficiary with same nickname already exits";
			return message;
		}
		PayeeInfo payeeDetails = new PayeeInfo();
		BeanUtils.copyProperties(payeeInfoVO, payeeDetails);
		payeeDetails.setDoe(new Timestamp(new Date().getTime()));
		payeeDetails.setDom(new Timestamp(new Date().getTime()));
		payeeDetails.setStatus("ASO4");
		payeeInfoRepository.save(payeeDetails);
		message = "Payee details have been saved successfully";
		return message;
	}
	
	
	@Override
	public List<PayeeInfoVO> findByCustomerId( String customerId) {
		List<PayeeInfo> payeeInfos = payeeInfoRepository.findByCustomerId(customerId);
		List<PayeeInfoVO> infoVOs = new ArrayList<PayeeInfoVO>();
		for(PayeeInfo pInfo:payeeInfos ) {
			PayeeInfoVO infoVO = new PayeeInfoVO();
			BeanUtils.copyProperties(pInfo, infoVO);
			infoVOs.add(infoVO );
		}
		
		return infoVOs;
				
	}
	
	

	
	@Override
	public void updateProfile(PayeeInfoVO payeeInfoVO) {
		//I have loaded entity inside persistence context - >>Session
		PayeeInfo payeeInfo=  payeeInfoRepository.findById(payeeInfoVO.getId()).get();
		BeanUtils.copyProperties(payeeInfoVO, payeeInfo,getNullPropertyNames(payeeInfoVO));
		payeeInfoRepository.save(payeeInfo);
	    
		}
	
	
	public  String[] getNullPropertyNames(Object source) {
		 BeanWrapper src = new BeanWrapperImpl(source);
		java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();
		Set<String> emptyNames = new HashSet<String>();
		for (java.beans.PropertyDescriptor pd : pds) {
			Object srcValue = src.getPropertyValue(pd.getName());
			if (srcValue == null)
				emptyNames.add(pd.getName());
		}
		String[] result = new String[emptyNames.size()];
		return emptyNames.toArray(result);
	}
	 


	@Override
	public void deletePayeeCustomerAccount(int payeeid) throws Exception {
		payeeInfoRepository.deleteById(payeeid);
		
	}
	
	
		
}
