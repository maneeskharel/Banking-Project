package com.rab3tech.customer.service.impl;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.rab3tech.customer.dao.repository.CustomerAccountInfoRepository;
import com.rab3tech.dao.entity.AccountStatus;
import com.rab3tech.dao.entity.AccountType;
import com.rab3tech.dao.entity.CustomerSaving;
import com.rab3tech.service.exception.BankServiceException;
import com.rab3tech.utils.Utils;
import com.rab3tech.vo.CustomerAccountInfoVO;
import com.rab3tech.vo.CustomerSavingVO;
import com.rab3tech.vo.EmailVO;

@Service
@Transactional
public class CustomerAccountInfoServiceImpl implements CustomerAccountInfoService {

	@Autowired
	private CustomerAccountInfoRepository customerAccountInfoRepository;

	public CustomerAccountInfoVO save(CustomerAccountInfoVO customerAccountInfoVO) {

		/*
		 * private long id; private String customerId; private String accountNumber;
		 * private String currency; private String branch; private float tavBalance;
		 * private float avBalance; private Date StatusAsOf; private String accountType;
		 */

		/*
		 * customerSavingVO.setDoa(new Date()); customerSavingVO.setAppref("AS-" +
		 * Utils.genRandomAlphaNum()); boolean b =
		 * TransactionSynchronizationManager.isActualTransactionActive(); if (b) {
		 * System.out.println("Ahahahahha tx is working!!!!!!!!!!!!!!"); }
		 * 
		 * CustomerSaving entity = new CustomerSaving();
		 * BeanUtils.copyProperties(customerSavingVO, entity, new String[] { "accType",
		 * "status" }); Optional<AccountType> oaccType =
		 * accountTypeRepository.findByName(customerSavingVO.getAccType()); if
		 * (oaccType.isPresent()) { entity.setAccType(oaccType.get()); } else { throw
		 * new BankServiceException("Hey this " + customerSavingVO.getAccType() +
		 * " account type is not valid!"); }
		 * 
		 * AccountStatus accountStatus = new AccountStatus(); accountStatus.setId(1);
		 * entity.setStatus(accountStatus);
		 * 
		 * CustomerSaving savingEntity = customerAccountEnquiryRepository.save(entity);
		 * 
		 * customerSavingVO.setCsaid(savingEntity.getCsaid());
		 * 
		 * System.out.println("Email sending .." + LocalDateTime.now());
		 * emailService.sendEquiryEmail(new EmailVO(customerSavingVO.getEmail(),
		 * fromEmail, null, "Hello! your account enquiry is submitted successfully.",
		 * customerSavingVO.getName())); System.out.println("Email done .." +
		 * LocalDateTime.now());
		 * 
		 * return customerSavingVO;
		 */
		
		
		return null;

	}

}
