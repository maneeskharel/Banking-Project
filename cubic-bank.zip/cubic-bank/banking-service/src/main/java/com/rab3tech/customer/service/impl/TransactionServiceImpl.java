package com.rab3tech.customer.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rab3tech.customer.dao.repository.CustomerAccountInfoRepository;
import com.rab3tech.customer.dao.repository.CustomerRepository;
import com.rab3tech.customer.dao.repository.LoginRepository;
import com.rab3tech.customer.dao.repository.PayeeInfoRepository;
import com.rab3tech.customer.dao.repository.TransactionRepository;
import com.rab3tech.customer.service.TransactionService;
import com.rab3tech.dao.entity.Customer;
import com.rab3tech.dao.entity.CustomerAccountInfo;
import com.rab3tech.dao.entity.Login;
import com.rab3tech.dao.entity.PayeeInfo;
import com.rab3tech.dao.entity.Transaction;
import com.rab3tech.vo.PayeeInfoVO;
import com.rab3tech.vo.TransactionVO;


@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepository transactionRepository;
	   
	@Autowired
      private  CustomerAccountInfoRepository  customerAccountInfoRepository;
     
	@Autowired
	private CustomerRepository  customerRepository;
	
	@Autowired
	private PayeeInfoRepository payeeInfoRepository;
	
	@Autowired
	private LoginRepository loginRepository;
	
	@Override
	public String transferFund(TransactionVO transactionVO) {
		 String message = null;
     // Customer customer = customerRepository.findByEmail(transactionVO.getCustomerId()).get();
		//check for account detail
      Login  login = loginRepository.findByLoginid(transactionVO.getCustomerId()).get();
	     Optional<CustomerAccountInfo> accountNum = customerAccountInfoRepository.findAccountByLogin(login);
		CustomerAccountInfo debitAccount = new CustomerAccountInfo();
		//cheking account type is saving or not 
		if (accountNum.isPresent()) {
			debitAccount = accountNum.get();
			if (!debitAccount.getAccountType().getCode().equalsIgnoreCase("AC001")) {
				message = "your savings account is not active";
				return message;
			}
			
	      //check sufficient balance 
	 		if (debitAccount.getAvBalance()<transactionVO.getAmount()) {
				message  = "Account has insufficient balance";
				return message;
			}
	 		
		} else {
			message = "You do not have a valid savings account";
			return message;
		}
		
   //checking Payee Information
	PayeeInfo payeeInfoVO =	payeeInfoRepository.findById(transactionVO.getPayeeId()).get();
     Optional<CustomerAccountInfo> creditNum = customerAccountInfoRepository.findByAccountNumber(payeeInfoVO.getPayeeAccountNo());
		if (!creditNum.isPresent()) {
			message = "payee account number is invalid";
			return message;
		}
		
		CustomerAccountInfo creditAccount = accountNum.get();
		if(!creditAccount.getAccountType().getCode().equalsIgnoreCase("AC001")) {
			message = "payee account is not active account";
			return message;
		}
		
		//update the balance of customer account 
	    float availableAmount = debitAccount.getAvBalance()- transactionVO.getAmount();
	    debitAccount.setAvBalance(availableAmount);
	 	customerAccountInfoRepository.save(debitAccount);
		
	 	
	 	//Update payee Amount
	 	float availabelBalance =creditAccount.getAvBalance()+transactionVO.getAmount();
	 	creditAccount.setAvBalance(availabelBalance);
	 	
	 	
	 	//updating the transaction table 
	 	 Transaction transaction = new Transaction();
	 	transaction.setAmount(transactionVO.getAmount());
	 	transaction.setDebitAccountNumber(creditAccount.getAccountNumber());
	 	transaction.setDescription(transactionVO.getDescription()); 
	 	transaction.setPayeeId(payeeInfoVO);
	 	transaction.setTransactionDate(new Timestamp(new Date().getTime()));
	 	transactionRepository.save(transaction);
	 	message = "fund transfer has been done successfully";
	     return message;
	}

	@Override
	public List<TransactionVO> getAllTransaction(String userid) {
		
		List<TransactionVO> transactionList = new ArrayList<TransactionVO>();
		//Customer customer = customerRepository.findByEmail(userid).get();
		Login  login = loginRepository.findByLoginid(userid).get();
	     Optional<CustomerAccountInfo> accountNum = customerAccountInfoRepository.findAccountByLogin(login);
	     CustomerAccountInfo debitAccount = accountNum.get();
	     List<Transaction> list = transactionRepository.getAllTransaction(debitAccount.getAccountNumber());
	   for (Transaction transactionDate : list) {
		 TransactionVO transactionVO = new TransactionVO();
		 if(transactionDate.getDebitAccountNumber().equals(debitAccount.getAccountNumber()))
		 {
			 transactionVO.setTransactionType("DEBIT");
		 }
		 else {
			 transactionVO.setTransactionType("CREDIT");
		 }
		 transactionVO.setAmount(transactionDate.getAmount());
		 transactionVO.setDescription(transactionDate.getDescription());
		 transactionVO.setTransactionDate(transactionDate.getTransactionDate());
		 PayeeInfoVO payee = new PayeeInfoVO();
		 BeanUtils.copyProperties(transactionDate.getPayeeId(), payee);
		 transactionVO.setPayee(payee);
		  transactionList.add(transactionVO);
	}
    return transactionList;
	}

}


