package com.rab3tech.utils;

public class Number {
	private int num;
	
	public Number(int num) {
		this.num = num;
	}
	
	public int factorial() {
		int sum =1;
		for (int x = 2; x <= num; x++) {
			sum = sum*x;
			}
		return sum;
		
	}

}
