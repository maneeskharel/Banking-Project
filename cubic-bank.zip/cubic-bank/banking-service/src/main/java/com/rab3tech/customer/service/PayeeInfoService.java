package com.rab3tech.customer.service;

import java.util.List;

import com.rab3tech.vo.PayeeInfoVO;

public interface PayeeInfoService {

	String savePayeInfo(PayeeInfoVO payeeInfoVO);
	List<PayeeInfoVO> findByCustomerId(String customerId);
	void deletePayeeCustomerAccount(int payeeid) throws Exception;
	void updateProfile(PayeeInfoVO payeeInfoVO);

}
